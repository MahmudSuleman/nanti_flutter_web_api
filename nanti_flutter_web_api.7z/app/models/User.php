<?php


namespace App\models;


class User extends Base
{

    protected $table = 'users';
}

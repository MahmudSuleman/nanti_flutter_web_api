<?php


namespace App\models;


class Company extends Base
{
    protected $table = 'companies';

}
